import React from 'react'

export default function page() {
  return (
    <div className="text-primary display-1 container">I am page in segment</div>
  )
}
