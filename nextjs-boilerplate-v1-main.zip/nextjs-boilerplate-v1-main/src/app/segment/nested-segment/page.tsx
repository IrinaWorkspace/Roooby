import React from 'react'

export default function page() {
  return (
    <div className="container text-primary display-main">
      OMG, the layout persists :O
    </div>
  )
}
