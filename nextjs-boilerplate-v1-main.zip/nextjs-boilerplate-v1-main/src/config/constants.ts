export const site_name = 'Zing7 Boilerplate'
